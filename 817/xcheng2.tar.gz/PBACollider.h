#ifndef __PBACOLLIDER_H__
#define __PBACOLLIDER_H__

#include "Common.h"
#include "PBAMath.h"

class PBAObject;

class PBACollider 
{
public: 
    PBACollider(PBAObject* obj = nullptr);

    const Vector3d& GetLoacalPosition() const;

public: 
    PBAObject* object;
    
protected: 
    Vector3d localPosition;
    Quaternion localRotation;

};

#endif