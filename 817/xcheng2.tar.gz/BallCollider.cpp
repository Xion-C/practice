#include "BallCollider.h"

BallCollider::BallCollider(PBAObject* obj) : 
    PBACollider(obj)
{

}