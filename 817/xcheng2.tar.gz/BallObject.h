#ifndef __BALLOBJECT_H__
#define __BALLOBJECT_H__

#include "Common.h"
#include "PBAObject.h"

class BallObject : public PBAObject 
{
public: 
    BallObject();
    virtual void Init() override;
    virtual void Update() override;
    virtual void Draw() override;

    void SetRidus(float);

public: 
    float radius;
};

#endif