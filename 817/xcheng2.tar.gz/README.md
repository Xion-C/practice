# Assignment 3 - Flocking System

Username: xcheng2
Name: Xin Cheng
Email: xcheng2@g.clemson.edu
Date: 10/14/2018

## Instructions:

    - Running command: ./flockingSystem parameters

    - The movements of the flocking boids are controlled by the lead boid

    - Parameters of the flocking system could be modified in the paramters file
    - Once the parameters file is changed, just press b to reload and restart

## Keyboard Control:

    - Press a/d/w/s/q/e to move the lead boid in x/y/z direction
    - Press p to enable/disable the lead boid moving

    - Press b to reload parameters and begin the simulation
    - Press space to pause the simulation
    - Press t to just generate one single particle
