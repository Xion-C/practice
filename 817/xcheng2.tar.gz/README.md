# Assignment 4 - Springy

Username: xcheng2
Name: Xin Cheng
Email: xcheng2@g.clemson.edu
Date: 10/30/2018

## Instructions:

    - Running command: ./springy parameters
    - Press t to show wireframe
