# Final Project - Breakout Game

Username: xcheng2
Name: Xin Cheng
Email: xcheng2@g.clemson.edu
Date: 12/04/2018

## Instructions:

    - Running command: ./run parameters

## Control:

    - Use mouse to move the paddle

