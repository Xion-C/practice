#include "PBACollider.h"
#include "PBAObject.h"
#include "PBAMath.h"

PBACollider::PBACollider(PBAObject* obj) : 
    object(obj),
    localPosition(Vector3d(0, 0, 0)),
    localRotation(Quaternion())
{
    localRotation.identity();
}

const Vector3d& PBACollider::GetLoacalPosition() const 
{
    return localPosition;
}