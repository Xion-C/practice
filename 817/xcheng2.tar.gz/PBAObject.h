#ifndef __PBAOBJECT_H__
#define __PBAOBJECT_H__

#include "Common.h"
#include "PBAMath.h"
//#include "ColliderMesh.h"
#include "PBACollider.h"
#include "Mesh.h"
#include "ObjectRenderer.h"

#include <string>

class PBAObject 
{
public: 
    PBAObject();
    virtual ~PBAObject();
    virtual void Init();
    virtual void Update();
    //virtual void Draw() const;
    virtual void Draw();

    void SetPosition(float x, float y, float z);
    void SetVelocity(float vx, float vy, float vz);
    void SetAngle(float yaw, float pitch, float roll);
    void SetAngularVelocity(float ux, float uy, float uz);
    void SetStatic(bool);
    void SetGravity(bool);

    const Vector3d& GetPosition() const {
        return position;
    }
    const Vector3d& GetVelocity() const {
        return velocity;
    }
    const Vector3d& GetAngularVelocity() const {
        return angularVelocity;
    }

    const Matrix3x3& GetRotMoiInv() const {
        return rotMoiInv;
    }

    float GetMass() const {
        return mass;
    } 

    void BindCollider(PBACollider*);


    /* this part need to be moved to renderer */
    void SetDiffuseColor(float, float, float, float a = 1.0);
    void SetSpecularColor(float, float, float, float a = 1.0);
    void SetShininess(float);


    //in world coordinates
    void AddImpulseAtPosition(const Vector3d&, const Vector3d&);

    //Matrix3x3 ComputeWorldToLocalMatrix();
protected: 
    void RefreshState();
    void ComputeEulerIntegration();

/* member */
public: 
    //ColliderMesh* colliderMesh;
    ObjectMesh* mesh;
    ObjectRenderer* renderer;
    PBACollider* collider;

    std::string name;

protected: 
    float mass, massInv;
    Matrix3x3 moi, moiInv; //moment of inertia
    Matrix3x3 rotMoi, rotMoiInv; //moment of inertia after rotation

    Vector3d position; //position
    Quaternion quaternion; //quaternion to express oritation
    Matrix3x3 rotation; //rotation matrix

    Vector3d velocity; //velocity
    Vector3d angularVelocity; //angular velocity

    Vector3d momentum; //momentum P
    Vector3d angularMomentum; //angular momentum L

    Vector3d force; //force
    Vector3d torque; //torque

    bool staticFlag;
    bool gravityFlag;

    /* this part need to be moved to renderer */
    std::vector<float> diffuseColor;
    std::vector<float> specularColor;
    float shininess;

};

#endif
