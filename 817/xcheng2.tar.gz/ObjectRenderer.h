#ifndef __OBJECTRENDERER_H__
#define __OBJECTRENDERER_H__

#include "Common.h"

class ObjectRenderer 
{
public: 
    virtual void Draw() const;
private: 
public: 

};

#endif