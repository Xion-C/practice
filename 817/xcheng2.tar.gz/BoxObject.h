#ifndef __BOXOBJECT_H__
#define __BOXOBJECT_H__

#include "Common.h"
#include "PBAObject.h"

#include <vector>

class BoxObject : public PBAObject 
{
public: 
    BoxObject();
    virtual void Init() override;
    virtual void Update() override;
    virtual void Draw() override;

    void SetSize(float, float, float);
    //const Vector3d& GetSize() const;

protected: 
    void ComputerMomentOfInertia();

public: 
    Vector3d size; //length, height, width - x y z 

};

#endif